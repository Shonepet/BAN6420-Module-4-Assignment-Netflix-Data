# Load necessary libraries
library(ggplot2)

# Import the CSV file
data <- read.csv("C:\\Users\\HP\\Desktop\\Nexford University\\BAN6420\\Module 4 Assignment- Netflix Data\\Unzipped File\\Netflix_shows_movies.csv")

# Check the first few rows of the data to ensure it's loaded correctly
print(head(data))

# Check unique genres
unique_genres <- unique(data$genre)
print(unique_genres)

# Most Watched Genres
genre_counts <- as.data.frame(table(data$genre))  # Count occurrences of each genre

# Ensure genre_counts is properly structured
if (ncol(genre_counts) == 1) {
  genre_counts <- data.frame(Genre = rownames(genre_counts), Count = genre_counts[[1]])
} else {
  colnames(genre_counts) <- c("Genre", "Count")
}

# Check the structure of genre_counts
print(str(genre_counts))

# Create the bar plot
ggplot(data = genre_counts, aes(x = reorder(Genre, -Count), y = Count)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(title = "Most Watched Genres", x = "Genres", y = "Number of Views") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

